import { useState, useEffect, useCallback } from 'react'
import Head from 'next/head'
import styles from '../styles/Home.module.css'

export default function Home() {
  const [tab, setTab] = useState('simples')
  const [leiloes, setLeiloes] = useState([])
  const [loading, setLoading] = useState(true)
  const [busca, setBusca] = useState('')
  const [filtroTipo, setFiltroTipo] = useState('')
  const [filtroDist, setFiltroDist] = useState('')
  const [preferenciaOuro, setPreferenciaOuro] = useState('')
  const [fipeAberta, setFipeAberta] = useState(false)
  const [fipeDesc, setFipeDesc] = useState('')
  const [fipeResult, setFipeResult] = useState(null)
  const [fipeLoading, setFipeLoading] = useState(false)
  const [ultimaAtualizacao, setUltimaAtualizacao] = useState(null)

  const buscarLeiloes = useCallback(async () => {
    setLoading(true)
    const params = new URLSearchParams()
    if (filtroTipo) params.set('tipo', filtroTipo)
    if (filtroDist) params.set('distancia', filtroDist)
    if (tab === 'ouro') {
      params.set('modo', 'ouro')
      if (preferenciaOuro) params.set('preferencia_tipo', preferenciaOuro)
    }
    const res = await fetch(`/api/leiloes?${params}`)
    const data = await res.json()
    setLeiloes(Array.isArray(data) ? data : [])
    setUltimaAtualizacao(new Date().toLocaleString('pt-BR'))
    setLoading(false)
  }, [filtroTipo, filtroDist, tab, preferenciaOuro])

  useEffect(() => { buscarLeiloes() }, [buscarLeiloes])

  const leiloesFiltrados = leiloes.filter(l => {
    if (!busca) return true
    const b = busca.toLowerCase()
    return (
      l.prefeitura?.toLowerCase().includes(b) ||
      l.tipo?.toLowerCase().includes(b) ||
      l.leiloeiro?.toLowerCase().includes(b)
    )
  })

  const consultarFipe = async () => {
    if (!fipeDesc.trim()) return
    setFipeLoading(true)
    setFipeResult(null)
    const res = await fetch('/api/fipe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ descricao: fipeDesc })
    })
    const data = await res.json()
    setFipeResult(data)
    setFipeLoading(false)
  }

  const corTipoBg = (tipo) => {
    if (tipo === 'Veículo Leve') return '#EAF3DE'
    if (tipo === 'Médio') return '#FAEEDA'
    return '#FCEBEB'
  }
  const corTipoText = (tipo) => {
    if (tipo === 'Veículo Leve') return '#3B6D11'
    if (tipo === 'Médio') return '#854F0B'
    return '#A32D2D'
  }
  const corDistBg = (km) => {
    if (km <= 300) return '#E1F5EE'
    if (km <= 800) return '#FAEEDA'
    return '#FCEBEB'
  }
  const corDistText = (km) => {
    if (km <= 300) return '#0F6E56'
    if (km <= 800) return '#854F0B'
    return '#A32D2D'
  }
  const corScoreBg = (cls) => {
    if (cls === 'Alta') return '#E1F5EE'
    if (cls === 'Média') return '#FAEEDA'
    return '#FCEBEB'
  }
  const corScoreText = (cls) => {
    if (cls === 'Alta') return '#0F6E56'
    if (cls === 'Média') return '#854F0B'
    return '#A32D2D'
  }
  const corBarraScore = (total) => {
    if (total >= 70) return '#1D9E75'
    if (total >= 45) return '#EF9F27'
    return '#E24B4A'
  }

  return (
    <>
      <Head>
        <title>Radar de Leilões Municipais</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main className={styles.main}>
        {/* Header */}
        <div className={styles.header}>
          <div>
            <h1 className={styles.titulo}>Radar de Leilões Municipais</h1>
            <p className={styles.subtitulo}>
              Leilões de veículos e inservíveis em prefeituras do Brasil
              {ultimaAtualizacao && (
                <span className={styles.atualizacao}> · Atualizado: {ultimaAtualizacao}</span>
              )}
            </p>
          </div>
        </div>

        {/* Topbar */}
        <div className={styles.topbar}>
          <input
            className={styles.busca}
            type="text"
            placeholder="Buscar por cidade, estado ou tipo..."
            value={busca}
            onChange={e => setBusca(e.target.value)}
          />
          <button className={styles.btnFipe} onClick={() => setFipeAberta(!fipeAberta)}>
            Consultar FIPE ↗
          </button>
        </div>

        {/* Painel FIPE */}
        {fipeAberta && (
          <div className={styles.fipePanel}>
            <h3 className={styles.fipeTitulo}>Consulta FIPE com IA</h3>
            <textarea
              className={styles.fipeInput}
              placeholder="Cole a descrição do veículo, ex: VW Gol 1.0 2015 branco 80.000 km..."
              value={fipeDesc}
              onChange={e => setFipeDesc(e.target.value)}
              rows={3}
            />
            <button className={styles.btnFipe} onClick={consultarFipe} disabled={fipeLoading}>
              {fipeLoading ? 'Analisando...' : 'Estimar valor ↗'}
            </button>
            {fipeResult && !fipeResult.erro && (
              <div className={styles.fipeResult}>
                <div className={styles.fipeGrid}>
                  <div><span className={styles.fipeLabel}>Marca</span><br /><strong>{fipeResult.marca}</strong></div>
                  <div><span className={styles.fipeLabel}>Modelo</span><br /><strong>{fipeResult.modelo}</strong></div>
                  <div><span className={styles.fipeLabel}>Ano</span><br /><strong>{fipeResult.ano}</strong></div>
                  <div><span className={styles.fipeLabel}>Versão</span><br /><strong>{fipeResult.versao}</strong></div>
                </div>
                <div className={styles.fipeValor}>
                  <span className={styles.fipeLabel}>Valor FIPE estimado</span>
                  <span className={styles.fipeValorNum}>{fipeResult.valor_fipe}</span>
                  {fipeResult.valor_minimo && (
                    <span className={styles.fipeRange}>({fipeResult.valor_minimo} – {fipeResult.valor_maximo})</span>
                  )}
                </div>
                {fipeResult.observacao && (
                  <p className={styles.fipeObs}>{fipeResult.observacao}</p>
                )}
              </div>
            )}
            {fipeResult?.erro && (
              <p className={styles.fipeErro}>Não foi possível identificar. Verifique a descrição.</p>
            )}
          </div>
        )}

        {/* Tabs */}
        <div className={styles.tabs}>
          <button
            className={`${styles.tab} ${tab === 'simples' ? styles.tabActive : ''}`}
            onClick={() => setTab('simples')}
          >
            Modo Simples
          </button>
          <button
            className={`${styles.tab} ${tab === 'ouro' ? styles.tabActive : ''}`}
            onClick={() => setTab('ouro')}
          >
            Modo OURO <span className={styles.badgeOuro}>★ OURO</span>
          </button>
        </div>

        {/* Filtros */}
        <div className={styles.filtros}>
          {tab === 'simples' ? (
            <>
              <label className={styles.filtroLabel}>Tipo:</label>
              <select className={styles.select} value={filtroTipo} onChange={e => setFiltroTipo(e.target.value)}>
                <option value="">Todos</option>
                <option value="Veículo Leve">Veículos Leves</option>
                <option value="Médio">Médios / Inservíveis</option>
                <option value="Sucata">Sucata / Pesados</option>
              </select>
              <div className={styles.divider} />
              <label className={styles.filtroLabel}>Distância:</label>
              <select className={styles.select} value={filtroDist} onChange={e => setFiltroDist(e.target.value)}>
                <option value="">Todas</option>
                <option value="green">Até 300 km</option>
                <option value="yellow">300–800 km</option>
                <option value="red">Acima 800 km</option>
              </select>
            </>
          ) : (
            <>
              <label className={styles.filtroLabel}>Preferência de tipo:</label>
              <select className={styles.select} value={preferenciaOuro} onChange={e => setPreferenciaOuro(e.target.value)}>
                <option value="">Qualquer</option>
                <option value="Veículo Leve">Veículos Leves</option>
                <option value="Médio">Médios</option>
                <option value="Sucata">Sucata / Pesados</option>
              </select>
            </>
          )}
        </div>

        {/* Lista de leilões */}
        {loading ? (
          <div className={styles.empty}>Carregando leilões...</div>
        ) : leiloesFiltrados.length === 0 ? (
          <div className={styles.empty}>
            Nenhum leilão encontrado.{' '}
            <button className={styles.linkBtn} onClick={buscarLeiloes}>Atualizar agora</button>
          </div>
        ) : (
          <div className={styles.lista}>
            {leiloesFiltrados.map((l) => (
              <div key={l.id} className={styles.card}>
                <div className={styles.cardTop}>
                  <span className={styles.cardPrefeitura}>{l.prefeitura}</span>
                  <span className={styles.cardData}>{l.data_leilao} às {l.hora_leilao}</span>
                </div>

                <div className={styles.cardMeta}>
                  <span className={styles.pill} style={{ background: corTipoBg(l.tipo), color: corTipoText(l.tipo) }}>
                    {l.tipo}
                  </span>
                  <span className={styles.pill} style={{ background: corDistBg(l.distancia_sp), color: corDistText(l.distancia_sp) }}>
                    {l.distancia_sp} km de SP
                  </span>
                  {l.leiloeiro && (
                    <span className={styles.pillNeutral}>{l.leiloeiro}</span>
                  )}
                </div>

                {/* Score (só no modo OURO) */}
                {tab === 'ouro' && l.score && (
                  <>
                    <div className={styles.scoreRow}>
                      <div className={styles.scoreBar}>
                        <div
                          className={styles.scoreFill}
                          style={{ width: `${l.score.total}%`, background: corBarraScore(l.score.total) }}
                        />
                      </div>
                      <span className={styles.scoreNum}>{l.score.total} pts</span>
                      <span
                        className={styles.scoreClass}
                        style={{ background: corScoreBg(l.score.classificacao), color: corScoreText(l.score.classificacao) }}
                      >
                        Oportunidade {l.score.classificacao}
                      </span>
                    </div>
                    <div className={styles.scoreDetalhes}>
                      <span>Tipo: {l.score.detalhes.tipo}pts</span>
                      <span>Cidade: {l.score.detalhes.populacao}pts</span>
                      <span>Leiloeiro: {l.score.detalhes.leiloeiro}pts</span>
                      <span>Valor: {l.score.detalhes.valor}pts</span>
                    </div>
                  </>
                )}

                {l.descricao && (
                  <p className={styles.cardDesc}>{l.descricao}</p>
                )}

                <a className={styles.cardLink} href={l.link} target="_blank" rel="noreferrer">
                  Ver edital / leilão ↗
                </a>
              </div>
            ))}
          </div>
        )}
      </main>
    </>
  )
}

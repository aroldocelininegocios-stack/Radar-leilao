// pages/api/leiloes.js
import { supabase } from '../../lib/supabase'
import { calcularScore } from '../../lib/score'

export default async function handler(req, res) {
  const { tipo, distancia, modo, preferencia_tipo } = req.query

  let query = supabase
    .from('leiloes')
    .select('*')
    .order('data_leilao', { ascending: true })

  // Filtro por tipo
  if (tipo) query = query.eq('tipo', tipo)

  // Filtro por distância
  if (distancia === 'green') query = query.lte('distancia_sp', 300)
  if (distancia === 'yellow') query = query.gt('distancia_sp', 300).lte('distancia_sp', 800)
  if (distancia === 'red') query = query.gt('distancia_sp', 800)

  const { data, error } = await query

  if (error) {
    return res.status(500).json({ erro: error.message })
  }

  // Calcula score para cada leilão
  const leiloesComScore = data.map(l => ({
    ...l,
    score: calcularScore(l, preferencia_tipo || ''),
  }))

  // Modo OURO: ordena por score e retorna top 8
  if (modo === 'ouro') {
    const ordenados = leiloesComScore
      .sort((a, b) => b.score.total - a.score.total)
      .slice(0, 8)
    return res.status(200).json(ordenados)
  }

  return res.status(200).json(leiloesComScore)
}

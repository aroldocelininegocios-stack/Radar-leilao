// pages/api/fipe.js
import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()

  const { descricao } = req.body
  if (!descricao) return res.status(400).json({ erro: 'Descrição obrigatória' })

  try {
    const message = await client.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 800,
      system: `Você é especialista em tabela FIPE brasileira. 
Analise a descrição de um veículo e retorne APENAS um JSON com:
{
  "marca": "",
  "modelo": "",
  "ano": "",
  "versao": "",
  "valor_fipe": "R$ XX.XXX",
  "valor_minimo": "R$ XX.XXX",
  "valor_maximo": "R$ XX.XXX",
  "observacao": "dica curta sobre o veículo"
}
Sem texto fora do JSON. Sem markdown.`,
      messages: [{ role: 'user', content: descricao }]
    })

    const texto = message.content.map(b => b.text || '').join('')
    const json = JSON.parse(texto.replace(/```json|```/g, '').trim())
    return res.status(200).json(json)
  } catch (e) {
    return res.status(500).json({ erro: 'Não foi possível identificar o veículo' })
  }
}

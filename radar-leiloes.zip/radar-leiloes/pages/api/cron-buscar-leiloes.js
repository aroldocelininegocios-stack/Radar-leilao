// pages/api/cron-buscar-leiloes.js
// Chamado automaticamente toda segunda-feira via Vercel Cron
// Também pode ser chamado manualmente: GET /api/cron-buscar-leiloes?secret=SUA_SENHA

import Anthropic from '@anthropic-ai/sdk'
import { supabaseAdmin } from '../../lib/supabase'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export default async function handler(req, res) {
  // Segurança: só roda com a senha correta
  const secret = req.query.secret || req.headers['x-cron-secret']
  if (secret !== process.env.CRON_SECRET) {
    return res.status(401).json({ error: 'Não autorizado' })
  }

  try {
    console.log('🔍 Iniciando busca semanal nos Diários Oficiais...')

    const hoje = new Date().toLocaleDateString('pt-BR')
    const semanaQue = new Date(Date.now() + 7 * 86400000).toLocaleDateString('pt-BR')

    // IA busca leilões reais nos Diários Oficiais
    const message = await client.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 4000,
      tools: [{ type: 'web_search_20250305', name: 'web_search' }],
      messages: [
        {
          role: 'user',
          content: `Você é um especialista em licitações públicas brasileiras. 
          
Busque nos Diários Oficiais municipais e sites de leilões públicos do Brasil leilões de veículos, caminhões e inservíveis agendados para a semana de ${hoje} a ${semanaQue}.

Pesquise em fontes como:
- diariooficial.net
- imprensaoficial.com.br  
- portaldatransparencia.gov.br
- licitacoes-e.com.br
- comprasnet.gov.br
- Sites de prefeituras

Para cada leilão encontrado, retorne um JSON com este formato exato (array de objetos):
[
  {
    "prefeitura": "Nome da Prefeitura / UF",
    "tipo": "Veículo Leve" | "Médio" | "Sucata",
    "distancia_sp": número em km de São Paulo,
    "data": "DD/MM/AAAA",
    "hora": "HH:MM",
    "link": "URL do edital ou leilão",
    "leiloeiro": "Nome do leiloeiro responsável",
    "populacao": número estimado de habitantes,
    "valor_estimado": valor médio estimado dos lotes em reais (número),
    "descricao": "breve descrição dos lotes"
  }
]

Retorne APENAS o JSON, sem texto adicional. Encontre pelo menos 8 leilões reais se possível.`
        }
      ]
    })

    // Extrai o texto da resposta
    const textoResposta = message.content
      .filter(b => b.type === 'text')
      .map(b => b.text)
      .join('')

    // Limpa e faz parse do JSON
    const jsonMatch = textoResposta.match(/\[[\s\S]*\]/)
    if (!jsonMatch) {
      throw new Error('IA não retornou JSON válido: ' + textoResposta.substring(0, 200))
    }

    const leiloes = JSON.parse(jsonMatch[0])
    console.log(`✅ IA encontrou ${leiloes.length} leilões`)

    // Deleta leilões antigos (mais de 7 dias)
    const seteDiasAtras = new Date(Date.now() - 7 * 86400000).toISOString()
    await supabaseAdmin
      .from('leiloes')
      .delete()
      .lt('created_at', seteDiasAtras)

    // Insere novos leilões no banco
    const { data, error } = await supabaseAdmin
      .from('leiloes')
      .insert(leiloes.map(l => ({
        prefeitura: l.prefeitura,
        tipo: l.tipo,
        distancia_sp: l.distancia_sp || 0,
        data_leilao: l.data,
        hora_leilao: l.hora,
        link: l.link,
        leiloeiro: l.leiloeiro,
        populacao: l.populacao || 0,
        valor_estimado: l.valor_estimado || 0,
        descricao: l.descricao || '',
        criado_em: new Date().toISOString()
      })))

    if (error) throw error

    console.log(`💾 ${leiloes.length} leilões salvos no banco`)
    return res.status(200).json({
      sucesso: true,
      total: leiloes.length,
      mensagem: `${leiloes.length} leilões atualizados com sucesso`
    })

  } catch (erro) {
    console.error('Erro na busca:', erro)
    return res.status(500).json({ erro: erro.message })
  }
}
